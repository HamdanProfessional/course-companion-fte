"""Test suite for Course Companion FTE Backend."""
