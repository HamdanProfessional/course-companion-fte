"""Storage layer (R2, cache)."""
