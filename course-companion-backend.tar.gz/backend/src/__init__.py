"""
Course Companion FTE Backend
Zero-Backend-LLM architecture - All AI intelligence happens in ChatGPT
"""

__version__ = "1.0.0"
