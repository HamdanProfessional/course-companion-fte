"""Database models and Pydantic schemas."""
